export const environment = {
  production: false,
  clienturlfor_cookie:'http://159.89.168.245:8080/',
  apiURL: 'http://143.110.244.51:8000/',
  
  isSkipLocationChange:true,
};

