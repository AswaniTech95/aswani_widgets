import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Location} from '@angular/common';
import { environment } from 'src/environments/environment';
import { SharedService } from '../service/shared.service';
import { DataService } from '../service/data.service';
const url = environment.clienturlfor_cookie
@Component({
  selector: 'app-widgetscreens',
  templateUrl: './widgetscreens.component.html',
  styleUrls: ['./widgetscreens.component.scss']
})

export class WidgetscreensComponent implements OnInit {
  
  widgetarray:any;
  login: any;
  cardList=[];
  constructor( private router: Router, private dataService: DataService,private location: Location,private sharedService:SharedService,  private route:ActivatedRoute) {
   
    const sessionData = localStorage.getItem("sessionData")
    let logindata = JSON.parse(sessionData);
    this.login = logindata.name;
  }
  
 
  testclick(link){
   window.open( url+
     "#/"+link, "_blank");
     
    
 
  }


  ngOnInit(): void {
    this.getMenuUrl();
  }

  private getMenuUrl() {
    this.dataService.getMenuUrl()
      .subscribe((results: any[]) => {
        let data = results['data'];
      
        
          this.sharedService.titleUrl = data[0].url;
        
       
          if(data.length>0){
          for(let i=0;i<=data.length;i++){
            if(data[i].type=='transaction'){
              this.cardList.push(data[i])
            }
          }
        }else{
          this.cardList=[]
        }
        // this.router.navigateByUrl(this.sharedService.titleUrl,{ skipLocationChange: true });
      })
  }

}
