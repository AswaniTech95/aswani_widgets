import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lodingspin',
  templateUrl: './lodingspin.component.html',
  styleUrls: ['./lodingspin.component.scss']
})
export class LodingspinComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
